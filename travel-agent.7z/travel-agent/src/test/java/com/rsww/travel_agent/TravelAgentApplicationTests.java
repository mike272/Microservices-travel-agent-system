package com.rsww.travel_agent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelAgentApplicationTests
{

	@Test
	void contextLoads() {
	}

}
