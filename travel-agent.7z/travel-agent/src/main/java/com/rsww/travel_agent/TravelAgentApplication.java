package com.rsww.travel_agent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelAgentApplication
{

	public static void main(String[] args) {
		SpringApplication.run(TravelAgentApplication.class, args);
	}

}
